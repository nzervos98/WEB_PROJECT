<?php


session_start();
	
	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["importfile"]["name"]);
	
	//Unique ID of current user
	$userid = $_SESSION['id'];
	
	
	if (move_uploaded_file($_FILES["importfile"]["tmp_name"], $target_file)){
		echo "The file ". basename( $_FILES["importfile"]["name"]). " has been uploaded.<br>";
	}

//parsing stage
//in order to use the salsify streaming parser you have to install composer for windows
//and then you have to install salsify streaming parser with the command : composer require salsify/json-streaming-parser in a directory that you have to name 
//jsonstreamingparser.That directory should be created in the dir that you store all your .php files
require_once __DIR__.'/jsonstreamingparser/vendor/autoload.php';

$testfile = $target_file;
$listener = new \JsonStreamingParser\Listener\myListener();
$stream = fopen($testfile, 'r');
try {
    $parser = new \JsonStreamingParser\Parser($stream, $listener);
    $parser->parse();
    fclose($stream);
} catch (Exception $e) {
    fclose($stream);
    throw $e;
}

//the implemented listener in this case myListener should be stored in the Listener dir of the jason streaming parser

?>
